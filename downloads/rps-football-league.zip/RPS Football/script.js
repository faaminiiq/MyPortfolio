// --- Konfigurasi Pasukan ---
const npcTeams = [
    "Manchester City", "Arsenal", "Liverpool", "Aston Villa", 
    "Tottenham", "Chelsea", "Newcastle", "Man United", 
    "West Ham", "Crystal Palace", "Brighton", "Bournemouth", 
    "Fulham", "Wolves", "Everton", "Brentford", 
    "Nottm Forest", "Luton", "Burnley"
];

let teams = [];
let fixtures = [];
let currentWeek = 0;
let userTeamName = "";

// State Perlawanan Semasa
let matchRoundsPlayed = 0;
let matchGoalsHome = 0;
let matchGoalsAway = 0;
let userIsHome = true;
let currentOpponent = "";

// --- Navigasi Skrin ---
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(screenId).classList.add('active');
}

// --- Inisialisasi Liga ---
function startGame() {
    const input = document.getElementById('team-input').value.trim();
    if (!input) {
        alert("Sila masukkan nama pasukan!");
        return;
    }
    
    userTeamName = input;
    
    // Bina objek statistik untuk semua pasukan
    teams = [{ name: userTeamName, p:0, w:0, d:0, l:0, gf:0, ga:0, gd:0, pts:0, isUser: true }];
    npcTeams.forEach(team => {
        teams.push({ name: team, p:0, w:0, d:0, l:0, gf:0, ga:0, gd:0, pts:0, isUser: false });
    });

    generateFixtures();
    updateDashboard();
    showScreen('dashboard-screen');
}

// --- Penjana Jadual (Round-Robin) ---
function generateFixtures() {
    let numTeams = teams.length;
    let indices = Array.from({length: numTeams}, (_, i) => i);
    
    for (let round = 0; round < numTeams - 1; round++) {
        let weekFixtures = [];
        for (let i = 0; i < numTeams / 2; i++) {
            weekFixtures.push({
                home: indices[i],
                away: indices[numTeams - 1 - i],
                played: false,
                homeScore: 0,
                awayScore: 0
            });
        }
        fixtures.push(weekFixtures);
        // Putar array (kecuali index 0)
        indices.splice(1, 0, indices.pop());
    }
}

// --- Papan Pemuka ---
function updateDashboard() {
    document.getElementById('week-indicator').innerText = `Minggu ${currentWeek + 1}`;
    
    // Isih Jadual Liga
    teams.sort((a, b) => {
        if (b.pts !== a.pts) return b.pts - a.pts; // Mata
        if (b.gd !== a.gd) return b.gd - a.gd;    // Perbezaan Gol
        return b.gf - a.gf;                       // Gol Dijaringkan
    });

    // Render Jadual
    const tbody = document.getElementById('table-body');
    tbody.innerHTML = "";
    teams.forEach((team, index) => {
        let row = `<tr class="${team.isUser ? 'user-team' : ''}">
            <td>${index + 1}</td>
            <td>${team.name}</td>
            <td>${team.p}</td>
            <td>${team.w}</td>
            <td>${team.d}</td>
            <td>${team.l}</td>
            <td>${team.gd > 0 ? '+'+team.gd : team.gd}</td>
            <td><strong>${team.pts}</strong></td>
        </tr>`;
        tbody.innerHTML += row;
    });

    // Render Jadual Perlawanan Minggu Ini
    const fixturesList = document.getElementById('fixtures-list');
    fixturesList.innerHTML = "";
    let thisWeek = fixtures[currentWeek];
    
    thisWeek.forEach(match => {
        let homeName = teams.find(t => t === getTeamOriginalRef(match.home)).name;
        let awayName = teams.find(t => t === getTeamOriginalRef(match.away)).name;
        let isUserMatch = (homeName === userTeamName || awayName === userTeamName);
        
        let displayScore = match.played ? `${match.homeScore} - ${match.awayScore}` : 'vs';
        
        fixturesList.innerHTML += `
            <div class="fixture-row ${isUserMatch ? 'user-team' : ''}">
                <span>${homeName}</span>
                <strong>${displayScore}</strong>
                <span>${awayName}</span>
            </div>
        `;
    });
}

function getTeamOriginalRef(index) {
    // Helper function kerana array `teams` di-sort sentiasa, kita perlukan rujukan asal.
    // Cara mudah: cari berdasarkan nama semasa memulakan liga.
    if(index === 0) return teams.find(t => t.name === userTeamName);
    return teams.find(t => t.name === npcTeams[index - 1]);
}

// --- Logik RPS (Perlawanan) ---
function enterMatch() {
    let thisWeek = fixtures[currentWeek];
    let userMatch = thisWeek.find(m => getTeamOriginalRef(m.home).name === userTeamName || getTeamOriginalRef(m.away).name === userTeamName);
    
    userIsHome = getTeamOriginalRef(userMatch.home).name === userTeamName;
    currentOpponent = userIsHome ? getTeamOriginalRef(userMatch.away).name : getTeamOriginalRef(userMatch.home).name;

    document.getElementById('home-team-name').innerText = userIsHome ? userTeamName : currentOpponent;
    document.getElementById('away-team-name').innerText = userIsHome ? currentOpponent : userTeamName;
    
    // Reset Stats
    matchRoundsPlayed = 0;
    matchGoalsHome = 0;
    matchGoalsAway = 0;
    document.getElementById('home-score').innerText = "0";
    document.getElementById('away-score').innerText = "0";
    document.getElementById('round-counter').innerText = "1";
    document.getElementById('action-text').innerText = "Pilih pergerakan anda:";
    
    document.getElementById('rps-controls').classList.remove('hidden');
    document.getElementById('back-dashboard-btn').classList.add('hidden');
    
    showScreen('match-screen');
}

function playRound(playerChoice) {
    const choices = ['rock', 'paper', 'scissors'];
    const cpuChoice = choices[Math.floor(Math.random() * 3)];
    
    let result = "";
    if (playerChoice === cpuChoice) {
        result = "Seri pusingan ini. Tiada gol.";
    } else if (
        (playerChoice === 'rock' && cpuChoice === 'scissors') ||
        (playerChoice === 'paper' && cpuChoice === 'rock') ||
        (playerChoice === 'scissors' && cpuChoice === 'paper')
    ) {
        result = "Anda menang pusingan ini! Gol!";
        if(userIsHome) matchGoalsHome++; else matchGoalsAway++;
    } else {
        result = "Komputer menang pusingan ini! Gol untuk lawan.";
        if(userIsHome) matchGoalsAway++; else matchGoalsHome++;
    }

    document.getElementById('home-score').innerText = matchGoalsHome;
    document.getElementById('away-score').innerText = matchGoalsAway;
    document.getElementById('action-text').innerText = `Anda: ${getIcon(playerChoice)} | Komputer: ${getIcon(cpuChoice)}. ${result}`;

    matchRoundsPlayed++;
    
    if (matchRoundsPlayed < 4) {
        document.getElementById('round-counter').innerText = matchRoundsPlayed + 1;
    } else {
        document.getElementById('action-text').innerText += " PERLAWANAN TAMAT!";
        document.getElementById('rps-controls').classList.add('hidden');
        document.getElementById('back-dashboard-btn').classList.remove('hidden');
    }
}

function getIcon(choice) {
    if(choice === 'rock') return '✊';
    if(choice === 'paper') return '✋';
    return '✌️';
}

// --- Kemaskini dan Simulasi ---
function finishMatch() {
    let thisWeek = fixtures[currentWeek];
    
    // Update User Match
    let userMatch = thisWeek.find(m => getTeamOriginalRef(m.home).name === userTeamName || getTeamOriginalRef(m.away).name === userTeamName);
    userMatch.played = true;
    userMatch.homeScore = matchGoalsHome;
    userMatch.awayScore = matchGoalsAway;
    applyMatchStats(userMatch.home, userMatch.away, matchGoalsHome, matchGoalsAway);

    // Simulate Other Matches
    thisWeek.forEach(match => {
        if (!match.played) {
            match.played = true;
            // Generate rawak antara 0 hingga 4 gol (sama seperti logik 4 RPS)
            match.homeScore = Math.floor(Math.random() * 5);
            match.awayScore = Math.floor(Math.random() * 5);
            applyMatchStats(match.home, match.away, match.homeScore, match.awayScore);
        }
    });

    currentWeek++;
    if (currentWeek >= fixtures.length) {
        alert("Musim tamat! Lihat kedudukan akhir liga anda.");
        document.getElementById('play-match-btn').classList.add('hidden');
    }
    
    updateDashboard();
    showScreen('dashboard-screen');
}

function applyMatchStats(homeIdx, awayIdx, homeGoals, awayGoals) {
    let homeTeam = getTeamOriginalRef(homeIdx);
    let awayTeam = getTeamOriginalRef(awayIdx);

    homeTeam.p++;
    awayTeam.p++;
    
    homeTeam.gf += homeGoals;
    homeTeam.ga += awayGoals;
    awayTeam.gf += awayGoals;
    awayTeam.ga += homeGoals;
    
    homeTeam.gd = homeTeam.gf - homeTeam.ga;
    awayTeam.gd = awayTeam.gf - awayTeam.ga;

    if (homeGoals > awayGoals) {
        homeTeam.w++; homeTeam.pts += 3;
        awayTeam.l++;
    } else if (homeGoals < awayGoals) {
        awayTeam.w++; awayTeam.pts += 3;
        homeTeam.l++;
    } else {
        homeTeam.d++; homeTeam.pts += 1;
        awayTeam.d++; awayTeam.pts += 1;
    }
}